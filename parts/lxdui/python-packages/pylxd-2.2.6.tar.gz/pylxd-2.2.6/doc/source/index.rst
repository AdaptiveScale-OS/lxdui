.. pylxd documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pylxd's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   usage
   authentication

   events
   certificates
   containers
   images
   networks
   profiles
   operations
   storage-pools

   contributing
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
